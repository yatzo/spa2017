#include <iostream>
#include <ctime>
#include "game_of_life.h"

using namespace std;

int game_of_life::random_value() {
    return rand() % 100 + 1;
}

bool game_of_life::cell_generate(int life_percentage) {
    int random = random_value();
    return ((random > 0) && (random <= life_percentage));
}

game_of_life::game_of_life()
{
    srand(time(nullptr));
    for (int i = 0; i < HORIZONTAL; i++)
    {
        for (int j = 0; j < VERTICAL; j++)
        {
            if (i == 0 || j == 0)
                _generacija[i][j] = 0;
            else if (i == HORIZONTAL - 1 || j == VERTICAL - 1)
                _generacija[i][j] = 0;
            else
                _generacija[i][j] = cell_generate(20);
        }
    }
}

void game_of_life::sljedeca_generacija() {
    for (int i = 1; i < HORIZONTAL - 1; i++)
    {
        for (int j = 1; j < VERTICAL - 1; j++)
        {
            int neighbours = 0;

            neighbours = _generacija[i - 1][j - 1] + _generacija[i - 1][j] + _generacija[i - 1][j + 1] + _generacija[i][j - 1] + _generacija[i][j + 1] + _generacija[i + 1][j - 1] + _generacija[i + 1][j] + _generacija[i + 1][j + 1];
            if (_generacija[i][j])
            {
                if (neighbours == 2 || neighbours == 3)
                    _sljedeca_generacija[i][j] = 1;
                else _sljedeca_generacija[i][j] = 0;
            }
            else {
                if (neighbours == 3)
                    _sljedeca_generacija[i][j] = 1;
                else _sljedeca_generacija[i][j] = 0;}
            }
        }
    for (int i = 0; i < HORIZONTAL; i++)
    {
        for (int j = 0; j < VERTICAL; j++)
        {
            _generacija[i][j] = _sljedeca_generacija[i][j];
        }
    }
    }

void game_of_life::iscrtaj() {
    system("cls");

    for (int i = 1; i < HORIZONTAL - 1; i++)
    {
        for (int j = 1; j < VERTICAL - 1; j++)
        {
            cout << (_generacija[i][j] ? "@" : " ");
        }
        cout << endl;
    }
}